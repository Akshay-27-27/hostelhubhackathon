import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart, CategoryScale, LinearScale, BarElement } from 'chart.js';
Chart.register(CategoryScale, LinearScale, BarElement);

const data = {
  labels: ['Open', 'In Progress', 'Resolved'],
  datasets: [
    {
      label: 'Complaints',
      data: [12, 19, 7], // TODO: Fetch from backend
      backgroundColor: [
        'rgba(255, 99, 132, 0.5)',
        'rgba(54, 162, 235, 0.5)',
        'rgba(75, 192, 192, 0.5)'
      ],
    },
  ],
};

export default function Analytics() {
  return (
    <div className="p-8">
      <h2 className="text-2xl mb-4">Analytics</h2>
      <Bar data={data} />
    </div>
  );
}
