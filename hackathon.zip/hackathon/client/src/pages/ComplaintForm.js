import React from 'react';
import { Formik, Form, Field } from 'formik';

export default function ComplaintForm() {
  return (
    <div className="p-8 max-w-lg mx-auto">
      <h2 className="text-2xl mb-4">Submit Complaint</h2>
      <Formik
        initialValues={{ title: '', description: '', priority: 'Low' }}
        onSubmit={values => {
          // TODO: Call backend complaint API
          alert(JSON.stringify(values, null, 2));
        }}
      >
        <Form className="bg-white p-6 rounded shadow-md">
          <div className="mb-4">
            <label>Title</label>
            <Field name="title" className="w-full p-2 border rounded" />
          </div>
          <div className="mb-4">
            <label>Description</label>
            <Field name="description" as="textarea" className="w-full p-2 border rounded" />
          </div>
          <div className="mb-4">
            <label>Priority</label>
            <Field name="priority" as="select" className="w-full p-2 border rounded">
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </Field>
          </div>
          <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded">Submit</button>
        </Form>
      </Formik>
    </div>
  );
}
