import React, { useEffect, useState } from 'react';

export default function AdvancedAnalytics({ token }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchStats() {
      setLoading(true);
      try {
        const res = await fetch('http://localhost:5000/api/analytics/advanced', {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await res.json();
        setStats(data);
      } catch (err) {
        setStats(null);
      }
      setLoading(false);
    }
    fetchStats();
  }, [token]);

  if (loading) return <div>Loading analytics...</div>;
  if (!stats) return <div>Could not load analytics.</div>;

  return (
    <div className="bg-white p-6 rounded shadow-md mb-6">
      <h2 className="text-xl font-bold mb-4">Advanced Analytics</h2>
      <div>
        <strong>Most Common Issues:</strong>
        <ul className="list-disc ml-6">
          {stats.mostCommonIssues.map(issue => (
            <li key={issue._id}>
              {issue._id} <span className="text-gray-500">({issue.count})</span>
            </li>
          ))}
        </ul>
      </div>
      <div className="mt-4">
        <strong>Average Resolution Time:</strong>
        <span className="ml-2">
          {stats.averageResolutionTimeHours.toFixed(2)} hours
        </span>
      </div>
    </div>
  );
}