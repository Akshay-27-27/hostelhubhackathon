import React from 'react';
import { Formik, Form, Field } from 'formik';

export default function Login() {
  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <Formik
        initialValues={{ email: '', password: '' }}
        onSubmit={values => {
          // TODO: Call backend login API
          alert(JSON.stringify(values, null, 2));
        }}
      >
        <Form className="bg-white p-8 rounded shadow-md w-80">
          <h2 className="text-2xl mb-4">Login</h2>
          <div className="mb-4">
            <label>Email</label>
            <Field name="email" type="email" className="w-full p-2 border rounded" />
          </div>
          <div className="mb-4">
            <label>Password</label>
            <Field name="password" type="password" className="w-full p-2 border rounded" />
          </div>
          <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">Login</button>
        </Form>
      </Formik>
    </div>
  );
}
